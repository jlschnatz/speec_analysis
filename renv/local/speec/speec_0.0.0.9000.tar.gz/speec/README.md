
<!-- README.md is generated from README.Rmd. Please edit that file -->

# speec

## Installation

You can install the development version of speec from
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("jlschnatz/speec")
```
