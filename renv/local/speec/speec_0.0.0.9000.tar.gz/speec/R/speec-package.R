#' @keywords internal
#' @aliases speec-package
"_PACKAGE"


## usethis namespace: start
#' @importFrom vctrs vec_cast
## usethis namespace: end
NULL
